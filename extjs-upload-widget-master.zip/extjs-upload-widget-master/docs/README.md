API documentation
=================

The documentation is generated with the [JSDuck tool](https://github.com/senchalabs/jsduck).
From this (`doc/`) directory run:

    jsduck --config jsduck-config.json
    
