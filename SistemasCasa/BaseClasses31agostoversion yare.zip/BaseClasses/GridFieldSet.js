
Ext.define("Ext.ux.SistemasCasa.BaseClasses.GridFieldSet", {
	extend: 'Ext.ux.SistemasCasa.BaseClasses.EditGrid',
    requires: [
	       'Ext.data.*',
	       'Ext.util.*',
	       'Ext.state.*',
	       'Ext.form.*',
	       'Ext.panel.Panel',
	       'Ext.view.View',
	       'Ext.layout.container.Fit',
	       'Ext.toolbar.Paging',
	       'Ext.ux.CheckColumn',
	       'Ext.grid.property.Grid',
	       'Ext.form.field.ComboBox'
	   ],
    actionsUrl: null,
    editable: true,
    layout: 'fit',
    stateful: false,
    loadingMask: true,
    border: false,
    height: '100%',
    alias: "widget.gridfieldset",
    itemId : 'gridfieldset',
    
    /**
    * @function    initComponent
    * @description this function gives the available tags which are shown in the searching grid
    * @returns     undefined
    **/
    initComponent: function() {
        var me = this;

        me.columns = null;
        
        
        if(this.editable) {
            me.plugins = [Ext.create("Ext.grid.plugin.CellEditing", {
                clicksToMoveEditor: 1,
                autoCancel: false
            })];
            
        }
        
        me.callParent();
    }
  	
});


