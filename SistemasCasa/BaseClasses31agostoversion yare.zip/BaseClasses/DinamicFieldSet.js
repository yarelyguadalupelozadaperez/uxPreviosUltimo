/**
 * @class Ext.ux.SistemasCasa.BaseClasses.MessageBox
 * @extends Ext.Msg
 * @autor Crysfel Villa
 * @date Fri Jul 29 10:15:49 CDT 2011
 *
 * Base class for MessageBox
 *
 *
 **/
Ext.require([
         "Ext.ux.SistemasCasa.BaseClasses.GridFieldSet"
 ]);

Ext.define('Ext.ux.SistemasCasa.BaseClasses.DinamicFieldSet',{
	extend 				: 'Ext.form.FieldSet',
	alternateClassName	: 'SistemasCasa.DinamicFieldSet',
	alias				: 'widget.dinamicfieldset',
    title: null,
    collapsible: true,
    width: '100%',
    height: 300,
    padding: 5,
    autoScroll: true,
    hidden: false,
    layout: 'fit',
    view: null,
    scheme: null,
    catalogClient : null,
    itemId : 'dinamicfieldset',
    flexColumns: [],
	where : null,
    grids: [],

    listeners: {
    	beforerender: function (a , b ) {
    		var me = this, 
    		grid1 = a.items.items[0];
    		
    		Ext.Ajax.request({
    			method: 'GET',
                url: 'application/index/getvieweditablegrid',
                params: {
                    view: me.view,
                    scheme: me.scheme,
                    catalogClient: me.catalogClient,
                    where : me.where
                },
                success: function (response) {
                   var gridConfig = Ext.JSON.decode(response.responseText);
                    
                    var store = {
                		autoLoad: false,
        	        	fields: gridConfig.fields,
        	            data: gridConfig.data,
        	            proxy: {
        	                type: 'ajax',
        	                url: 'application/index/getvieweditablegrid',
        	                extraParams: {
        	                    view: me.view,
        	                    scheme: me.scheme,
        	                    catalogClient: me.catalogClient,
        	                    where : me.where
        	                   
        	                },
        	                reader: {
        	                    type: 'json',
        	                    rootProperty: 'data'
        	                }
        	            },
        	        	listeners: {
        	                beforesync: function (options, eOpts) {
        	                	console.log(options);
        	                	console.log("hola");
        	                	return;
        	                	if(options.destroy === undefined) {
        	                        if(options.update[0].data.id_descripmerc == 0 &&
        	                          (options.update[0].data.descrip_mercancia == '' ||
        	                           options.update[0].data.estatus_mercancia == 0)) {
        	                            return false;
        	                        } else {
        	                            if(options.update[0].data.id_descripmerc == 0) {
        	                                this.load();
        	                            }
        	                            return true;
        	                        }
        	                	} else {
        	                		return true;
        	                	}	
        	                }
        	            },
        	        };
                    var columns = Array();
                    var counter = 0;
                    
                    Ext.Array.each(gridConfig.columns, function(column, index) {
                    	columns.push(
                			{
                				text: column.text, 
                				dataIndex: column.dataIndex, 
                				flex: (me.flexColumns[index] === undefined ? 1 : me.flexColumns[index]),
                				autoSizeColumn: true,
                				hidden: (column.hidden === undefined ? false : column.hidden),
                				cellWrap: true,
                				renderer: this.showActive,
                				tdCls: 'x-change-cell',
                				
                				editor: {
	            					listeners: {
	            	                    change: function(field, newValue, oldValue) {
	            	                        field.setValue(newValue.toUpperCase());
	            	                    }
	            	                 }
                				}
            				}
            			); 
        		    });


                    grid1.reconfigure(store, columns);

                    var count = grid1.getStore().count();
                },
                
                failure: function (response) {
                    EDespacho.Msg.alert(response.message);
                }
            });
    	}, 
    },
    
    initComponent	: function() {
        var me = this;
        me.items = [{
			xtype: 'gridfieldset',
			itemId: me.configGrid.id,
	        border: false,
	        loadMask: true,
	        stateful: false,
	        autoScroll: true,
	        loadMask: true,
	        listeners: { 
	        	itemmousedown: function(grid, e, eOpts){ 
	                var datos = me.configGrid.grids;
	            	Ext.ComponentQuery.query('#'+me.configGrid.dinamicfieldset)[0].setTitle('<b><font size = 2, color="#3892d4"> '+ me.configGrid.title +' </font></b>');
	            	Ext.ComponentQuery.query('#'+me.configGrid.dinamicfieldset)[0].getEl().dom.style.border = 'solid 1px #3892d4';   
	            	for (var i=0; i<datos.length; i++) 
	            	{
	            		if(datos[i][0] != me.configGrid.id){
	            			Ext.ComponentQuery.query('#'+datos[i][2])[0].setTitle('<b><font size = 2, color="#7f7f7f"> '+ datos[i][1] +' </font></b>');
	    	            	Ext.ComponentQuery.query('#'+datos[i][2])[0].getEl().dom.style.border = 'solid 1px #cfcfcf';   
	            		}
            		}
	        	},
	        	
	        	containerclick: function(container, e, eOpts){ 
	                var datos = me.configGrid.grids;
	            	Ext.ComponentQuery.query('#'+me.configGrid.dinamicfieldset)[0].setTitle('<b><font size = 2, color="#3892d4"> '+ me.configGrid.title +' </font></b>');
	            	Ext.ComponentQuery.query('#'+me.configGrid.dinamicfieldset)[0].getEl().dom.style.border = 'solid 1px #3892d4';   
	            	for (var i=0; i<datos.length; i++) 
	            	{
	            		if(datos[i][0] != me.configGrid.id){
	            			Ext.ComponentQuery.query('#'+datos[i][2])[0].setTitle('<b><font size = 2, color="#7f7f7f"> '+ datos[i][1] +' </font></b>');
	    	            	Ext.ComponentQuery.query('#'+datos[i][2])[0].getEl().dom.style.border = 'solid 1px #cfcfcf';   
	            		}
            		}
	        	},
	        	
	        	headerclick : function (header, column, e, t, eOpts){
	                var datos = me.configGrid.grids;
	            	Ext.ComponentQuery.query('#'+me.configGrid.dinamicfieldset)[0].setTitle('<b><font size = 2, color="#3892d4"> '+ me.configGrid.title +' </font></b>');
	            	Ext.ComponentQuery.query('#'+me.configGrid.dinamicfieldset)[0].getEl().dom.style.border = 'solid 1px #3892d4';   
	            	for (var i=0; i<datos.length; i++) 
	            	{
	            		if(datos[i][0] != me.configGrid.id){
	            			Ext.ComponentQuery.query('#'+datos[i][2])[0].setTitle('<b><font size = 2, color="#7f7f7f"> '+ datos[i][1] +' </font></b>');
	    	            	Ext.ComponentQuery.query('#'+datos[i][2])[0].getEl().dom.style.border = 'solid 1px #cfcfcf';   
	            		}
            		}
	        	}
	        } 
       
        }];
        
        if(this.editable){
			this.editing = Ext.create('Ext.grid.plugin.CellEditing');
			me.plugins = [this.editing];
		}
		
		me.callParent();
		
    },

	showActive	: function(value, otrovalor){
		if(value == true || value == 1) {
			return '<center><img src="localhost/e-despacho/public/themes/default/images/icons/16/accept.png">';
		} else {
			return '<center><img src="localhost/e-despacho/public/themes/default/images/icons/16/accept.png">';
		}
	},
});
