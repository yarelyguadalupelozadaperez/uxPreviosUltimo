/**
 * @class Ext.ux.SistemasCasa.BaseClasses.MessageBox
 * @extends Ext.Msg
 * @autor Crysfel Villa
 * @date Fri Jul 29 10:15:49 CDT 2011
 *
 * Base class for MessageBox
 *
 *
 **/

Ext.define('Ext.ux.SistemasCasa.BaseClasses.WindowsHelp',{
	extend 				: 'Ext.window.Window',
	alternateClassName	: 'SistemasCasa.WindowsHelp',
	title: 'WindowsHelp',
	requires	: [
   		'Ext.ux.SistemasCasa.BaseClasses.LiveSearchGrid'
   	],
    height: 400,
    width: 500,
    focusOnToFront: true,
    layout: 'fit',
    modal: true,
    maximizable: true,
    autoShow: true,
    rootEl: null,
    nameField: null,
    idTargetField: 0,
    
    listeners: {
    	beforerender: function (window , eOpts ) {
    		var grid = window.items.items[0];
    		Ext.Ajax.request({
                url: 'application/index/getview',
                params: {
                    view: window.view,
                    schema: window.schema
                },
                success: function (response) {
                    var gridConfig = Ext.JSON.decode(response.responseText);
                    
                    var store = {
                		autoLoad: true,
        	        	fields: gridConfig.fields,
        	            data: gridConfig.data
        	        };
                    
                    grid.reconfigure(store, gridConfig.columns);
                },
                
                failure: function (response) {
                    EDespacho.Msg.alert(response.message);
                }
            });
    	}
    },
    
    initComponent	: function() {
        var me = this;
        
        me.items = [{
			xtype: 'livesearchgrid',
	        border: false,
	        loadMask: true,
	        stateful: false,
	        autoScroll: true,
	        loadingMask: true,
	        //bufferedRenderer: true,
	        listeners: {
	        	itemdblclick: function (grid ,record, item, index, e, eOpts) {
	        		var rootEl = me.rootEl,
	        			newValue = record.get(me.nameField);	
	        		
	        		try {
	        			var selectedModel = rootEl.getSelectionModel().getSelection()[0];
		                selectedModel.set(rootEl.getLastFocused().column.dataIndex, newValue);
		                selectedModel.set(me.idTargetField, record.data.id);
		                rootEl.getStore().sync();
	        		} catch (e) {
	        			Ext.getCmp(rootEl.id).setValue(newValue);
	        			Ext.getCmp(me.idTargetField).setValue(record.data.id);
	        			
	        		}	        		
	        		
	        		me.close();
	        	},
	        	
	        	rowbodykeydown : function () {
	        		console.log('Hola a todos');
	        	}
	        },
	        
	        columns: [
                  	{ text: 'Nombre', dataIndex: 'name' },
			],
	              
	        store: {
	        	fields:[ 'name'],
	            data: [
	                { name: '' },
	            ]
	        }
		}];
        
		me.callParent();
		
    }   
    
});