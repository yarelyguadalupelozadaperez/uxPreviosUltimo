Ext.define('Ext.ux.SistemasCasa.BaseClasses.Model', {
    extend		: "Ext.data.Model",
	idProperty	: "id",
	rootProperty    : "data",
	fields		: []
});