Ext.define("Ext.ux.SistemasCasa.model.Model",{
	extend : "Ext.data.Model",
        
});